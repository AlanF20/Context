import './assets/background.js-DmFmaMUG.js';
